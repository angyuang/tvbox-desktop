# 更新日志

## 1.6.2（2026-11-17）

清理编译期仅剩的两条无害告警，功能零改动：

- 清理：删除 `search.rs` 中遗留未用的常量 `MAX_CONCURRENCY`。聚合搜索并发早已改由设置页「聚合搜索并发数」（1-32，默认 6）驱动，该常量自 1.2.0 起即无引用
- 清理：`models.rs` 中 `TvboxConfig` 的 `warningText` 字段改名 `warning_text` 并加 `#[serde(rename = "warningText")]`——对外 JSON 键保持不变，TVBox A 格式配置（`spider` / `wallpaper` / `warningText` 兼容字段）解析行为完全一致
- 现在 `npm run tauri:dev` / `npm run tauri:build` 的编译输出零告警；其余与 1.6.1 完全一致

## 1.6.1（2026-11-17）

修复 1.6.0 源码包在 Windows 上 `npm install` 后 `npm run tauri:dev` / `npm run tauri:build` 启动即报错的问题：

- 修复：`tauri.conf.json` 窗口主题值 `"dark"` → `"Dark"`。新版 `@tauri-apps/cli`（本包锁定 2.12.4）的内嵌校验 schema 把 `app > windows > theme` 的枚举从旧版小写 `"light"/"dark"` 改为首字母大写 `"Light"/"Dark"`，旧值会在启动前的 schema 校验阶段被拦下，报错 `app > windows > 0 > theme: "dark" is not valid under any of the schemas listed in the 'anyOf' keyword`。已实测：CLI 2.12.4 校验通过、cargo check（Rust 侧 tauri-utils 2.10.3 解析 conf）通过，深色标题栏行为与 1.6.0 一致，运行时主题切换（设置 → 通用）不受影响
- 同步：package.json / Cargo.toml / tauri.conf.json / package-lock.json / Cargo.lock 版本号统一到 1.6.1（1.6.0 的 lock 文件根版本号漏更，npm 会自动纠正，但本次一并修正避免混淆）
- 其余功能与 1.6.0 完全一致，无需其他操作

## 1.6.0（2026-11-17）

本版本三件套：配置文件可见可改、版本与更新检查、360资源内置 + 刷新不再覆盖手工改动。同时本包把 1.3.0–1.5.0 期间的功能一并重建交付（那几个版本的构建源未持久化到当前环境），功能清单见下方对应条目。

- 新增（需求①）：配置文件不再"隐身"。设置 → 关于 直接展示数据目录与四个配置文件（subscriptions.json / settings.json / favorites.json / history.json）的用途说明，一键「打开目录」；新增「重新加载配置」按钮，手工改完 JSON 无需重启立即生效
- 新增：便携模式——在 exe 同目录建一个 `data` 文件夹，应用启动时自动优先使用它（subscriptions.json 等全部放里面），配置可随目录整体拷贝迁移；未建 data 文件夹则仍用系统数据目录，关于区会显示当前处于哪种模式
- 新增（需求②）：设置 → 关于 显示当前版本号 +「检查更新」按钮；设置 → 通用 新增「更新地址」字段（update_url），支持 JSON 清单 `{"version":"x.y.z","notes":"…","url":"下载页"}` 或纯文本版本号两种格式，发现新版会显示版本号/更新说明并可一键打开下载页
- 新增（需求③）：内置订阅新增「360资源」站点（360zy，api: https://360zyzz.com/api.php/provide/vod）；订阅「刷新」改为合并策略——新配置里没有、旧配置里有的站点/直播/解析（手工新增的源）原样保留，同名站点的停用状态也保留，不再出现"刷新后自己加的源被覆盖"
- 修复：苹果CMS 返回字符串数字（"vod_id":"123"、"searchable":"1"、布尔值）时整包解析失败的问题，全部字段改为宽松解析

### 1.6.0 一并重建的历史功能（1.3.0–1.5.0）

- 深色主题（默认）+ 浅色主题可切换，Windows 标题栏颜色同步跟随；主题在设置 → 通用 选择
- 聚合搜索：搜索历史记录（最近 10 条，点击重搜、单条删除、最多 20 条持久化）
- 聚合搜索：结果跨页面保活（切到别的页面再回来，关键词与结果还在，不自动重搜）
- 聚合搜索：结果卡片点击直接展开「片源标签 + 选集」，点集数进入播放页走与详情页完全相同的解析管线内嵌播放；嗅探只命中 1 条直链时自动选路播放，不再弹"请选择"；多链/解析接口/嗅探窗口逐级兜底，杜绝弹新窗口播放
- 影视源：每个站点增加启用开关（亮色=启用 / 灰色=停用，一眼区分），停用站点不参与聚合搜索与浏览，状态持久化到订阅配置
- 影视源：「批量测试全部站点」按钮，并发 4 路逐个显示 ✓ / ✗ / … 状态
- 新增「本地播放」页：选择本机视频/音频文件（可多选）用内置播放器播放，列表本机保存
- CMS 解析报错修复（宽松数字解析 + GBK 编码兜底在 1.2.x 已具备，本版补齐 vod_id/分页字段等遗漏字段）

## 1.2.0（2026-11-16）

对齐原版设置页（配置源 / 解析接口 / 通用 / AI 总结 / 关于）：

- 新增：订阅启用开关、重命名、同步时间显示，列表统计（站点/直播/解析数）；禁用订阅自动回退生效配置
- 新增：解析接口（parses）兜底——网页线路嗅探失败后按订阅 parses 顺序依次解析，设置页可测试接口
- 新增：通用设置并持久化到 settings.json：聚合搜索并发数（1-32）、请求超时、界面密度（舒适/紧凑）、强调色（CSS 变量实时生效）、搜索结果过滤解说/速看/混剪、自定义 User-Agent（贯通 CMS/搜索/直播/嗅探全链路）
- 新增：外部播放器命令模板（{url} 占位，支持 --fullscreen 等参数）+「检测本机播放器」
- 新增：AI 总结本集（DeepSeek / OpenAI 兼容接口，Rust 端调用，仅发送片名/集名/类型/年份/演员/简介，不发送播放地址）
- 新增：关于区（版本 / 数据目录一键打开 / 运行环境 / 免责声明）
- Tauri 命令 25 → 33 个，新增模块 settings.rs / parse.rs / ai.rs

## 1.0.1（2026-11-16）

- 新增：一键外部播放器。详情页/直播页/嗅探结果均可把直链交给本机 PotPlayer / VLC / mpv / IINA；未配置时按常见安装路径自动探测，设置页可手动指定程序路径（Rust `std::process` 拉起，新增 `open_external_player` 命令与 `external.rs` 模块）
- 修复：Windows 下 `tauri dev` 启动即崩（Vite 监听 `src-tauri/target/` 碰到 Cargo 锁定的 .exe 抛 EBUSY，现已在 `vite.config.ts` 忽略 Rust 构建目录）
- 修复：`cms.rs` 两处编译错误（模板参数 `&str` 借用、选集解析 move 后借用）

## 1.0.0（2026-11-16）

首个 Tauri 2 重写版，基于 hgtuj5688/tvbox-desktop（Electron）全功能对齐：

- 订阅源管理：URL / 本地 JSON / 粘贴配置三种添加方式，刷新、激活、删除
- TVBox A/B 双格式兼容，站点类型矩阵（cms/api/html 支持，spider/unknown 灰显说明）
- 分类浏览 + 分页，站点连通性测试
- 聚合搜索：Rust tokio 并发（6 路）、单站 12s 超时、进度事件
- 详情：多播放源、选集、收藏
- 播放：ArtPlayer + hls.js，观看进度 8 秒节流记忆 + 自动续播
- 直播电视：m3u/txt 解析、同名频道多线路合并、并发测速
- 房间号：huya:// / douyin:// 实验性解析
- 简易嗅探：HTML 直取正则提取（主通道）+ Webview hook 窗口（增强通道）
- 首页推荐位：tvboxDesktop.home.sections，缺失时回退站点最新列表
- 三平台打包配置（NSIS / dmg / deb+AppImage），图标全套生成脚本
